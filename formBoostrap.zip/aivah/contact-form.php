<?php
	// Receiver mail id 
	$mail_to = 'khanfairy94@gmail.com';

	// Mail Subject 
	$subject = 'Aivahthemes';

	if ($_SERVER["REQUEST_METHOD"] == "POST") {

	    if ( isset($_POST['first_name']) ) {
	        $first_name = $_POST['first_name'];
	    }
	    if (isset($_POST['last_name'])) {
	        $last_name = $_POST['last_name'];
	    }

	    if (isset($_POST['email'])) {
	        $email = $_POST['email'];
	    }

	    if (isset($_POST['city'])) {
	        $city = $_POST['city'];
	    }

	    if (isset($_POST['state'])) {
	        $state = $_POST['state'];
	    }

	    if (isset($_POST['zip'])) {
	        $zip = $_POST['zip'];
	    }

	    // Message body

		$msg = '<html><body><p>';

	    $msg .= '<b> First Name : </b>' . $first_name . '<br/>';

		if($_POST["last_name"] != "") {
	       $msg .= '<b> Last Name : </b>' . $last_name . '<br/>';
	    }

	    if($_POST["email"] != "") {
	       $msg .= '<b> Email : </b>' . $email . '<br/>';
	    }

	    if($_POST["city"] != "") {
	       $msg .= '<b> City : </b>' . $city . '<br/>';
	    }

	    if($_POST["state"] != "") {
	       $msg .= '<b> State : </b>' . $state . '<br/>';
	    }

	    if($_POST["zip"] != "") {
	       $msg .= '<b> Zip : </b>' . $zip . '<br/>';
	    }

		$msg .= '</p>';
		$msg .= '</body></html>';

		// Mail headers
		$headers  = "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
		$headers .= 'From: fem.iva@gmail.com' . "\r\n";

		if( mail( $mail_to, $subject, $msg, $headers )) {
			echo "Thank You!";
		} else {
			die("Error!");
	    }
	}
?>
