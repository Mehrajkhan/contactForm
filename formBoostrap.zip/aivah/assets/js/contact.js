
$(document).ready(function() {

    // reCaptcha random numbers generate
     function randomNumber(min, max) {
        return Math.floor(Math.random() * (max - min + 1) + min);
    };

    function generateCaptcha() {
        $('#captchaOperation').html([randomNumber(1, 5), '+', randomNumber(1, 10), '='].join(' '));
    };

    generateCaptcha();

    // Form validations
  $('#contact_form').bootstrapValidator({

        fields: {
            first_name: {
                validators: {
                    stringLength: {
                        min: 2,
                    },
                    notEmpty: {
                        message: 'Please supply your first name'
                    }
                }
            },
            last_name: {
                validators: {
                    stringLength: {
                        min: 2,
                    },
                    notEmpty: {
                        message: 'Please supply your last name'
                    }
                }
            },
            email: {
                validators: {
                    notEmpty: {
                        message: 'Please supply your email address'
                    },
                    emailAddress: {
                        message: 'Please supply a valid email address'
                    }
                }
            },

            city: {
                validators: {
                    stringLength: {
                        min: 4,
                    },
                    notEmpty: {
                        message: 'Please supply your city'
                    }
                }
            },
            state: {
                validators: {
                    stringLength: {
                        min: 4,
                    },
                    notEmpty: {
                        message: 'Please select your state'
                    }
                }
            },
            zip: {
                validators: {
                    notEmpty: {
                        message: 'Please supply your zip code'
                    },
                    regexp: {
                        regexp: /^\d{10}$/,
                        message: 'The US zipcode must contain 5 digits'
                    }
                }
            },
            agree: {
                validators: {
                    notEmpty: {
                        message: 'You must agree with the terms and conditions'
                    }
                }
            },
            captcha: {
                validators: {
                    callback: {
                        message: 'Wrong answer',
                        callback: function (value, validator, $field) {
                            // Determine the numbers which are generated in captchaOperation
                            var items = $('#captchaOperation').html().split(' '),
                            sum   = parseInt(items[0]) + parseInt(items[2]);
                            return value == sum;
                        }
                    }
                }
            }
        },

        // Success Message display
        submitHandler: function(validator, form, submitButton) {
            generateCaptcha();
            $('#success_message').css('opacity','1').fadeIn().delay(3000).fadeOut();  

            var bv = form.data('bootstrapValidator');

            // Use Ajax to submit form data
            $.post(form.attr('action'), form.serialize(), function(result) {
                
            }, 'json');
            $('#contact_form').bootstrapValidator('resetForm', true);
            
            //checkbox reset
            $('.form-check-input').prop('checked', false);
        }
    })
    .on('error.form.bv', function (e) {
        generateCaptcha();
    });
    
});
